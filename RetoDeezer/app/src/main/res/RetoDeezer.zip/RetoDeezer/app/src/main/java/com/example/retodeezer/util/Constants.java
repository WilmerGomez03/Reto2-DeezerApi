package com.example.retodeezer.util;

public class Constants {

    public static final int SEARCH_CALLBACK = 1;
    public static final int PLAYLIST_CALLBACK = 2;
    public static final int TRACKS_CALLBACK = 3;
}
